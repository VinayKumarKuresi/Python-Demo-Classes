
First CLass :

'''
    1) Introduction to Python
    2) Flight Example
    3) What is Program
    4) Three step  of Solving a Problem :
          1) Input
          2) Process(Algorithm)
          3) Output
          
    5) Representaion of Algorithm :
          1) Pseudo - code
          2) Flow Chart
          
    6) Variables
    7) Operators :
          1) Arithematice Operator
          2) Logical Operator
          3) Relational Operator
          
    8) Flow of COntrols :
          1) Selection Control Structure
                  eg : runway example
                        a) Single selection statement
                        b) Multi selection statement
		      2) Repetitive COntrol Struture  
          
  '''
