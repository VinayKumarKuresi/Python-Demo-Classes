Python 3.7.8 (tags/v3.7.8:4b47a5b6ba, Jun 28 2020, 08:53:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Vinay")
Vinay
>>> initial_no_of_flights = 100
>>> take_off = 40
>>> landed_planes = 60
>>> 
>>> Current_number_of_flights  = initial_no_of_flights  - take_off  + landed_planes
>>> 
>>> Current_number_of_flights
120
>>> initial_no_of_flights
100
>>> 
>>> num1 = 6
>>> num2 = 3
>>> 
>>> num1 % num2
0
>>> num1 / num2
2.0
>>> num1 * num2
18
>>> initial_no_of_flights == 80
False
>>> initial_no_of_flights == 100
True
>>> 
>>> runway = "free"
>>> 
>>> if runway == "free":
	print("Land the plance")
else :
	print("Circle in air")

	
Land the plance
>>> 
>>> runway = "Not free"
>>> 
>>> f runway == "free":
	print("Land the plance")
else :
	print("Circle in air")
	
SyntaxError: invalid syntax
>>> 
>>> if runway == "free":
	print("Land the plance")
else :
	print("Circle in air")

	
Circle in air
>>> 
>>> 