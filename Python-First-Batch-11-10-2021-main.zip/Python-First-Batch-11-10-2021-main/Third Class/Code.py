
runway = "not free"
fuel = "low"

if(runway == "free"):
    print("flight can land")

if(fuel == "low"):
    print("flight can emergency land")
else :
    print("flight cannnot land")

passenger = 1
display("Number of passenger count", passenger)

passenger = passenger + 1
display("Number of passenger count", passenger)

passenger = passenger + 1
display("Number of passenger count", passenger)

passenger = passenger + 1
display("Number of passenger count", passenger)

passenger = passenger + 1
display("Number of passenger count", passenger)

Total_No_of_passenger = 6
passenger_count = 1
for passenger_count in range(1, Total_No_of_passenger):
	print("Number of passenger count", passenger_count)



