Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  4 2021, 13:27:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> current = 100
>>> take = 50
>>> land = 23
>>> present = current - take + land
>>> present
73
>>> present = current - take + land
>>> present
73
>>> passenger = 1
>>> passenger = passenger + 1
>>> passenger = passenger + 1
>>> passenger = passenger + 1
>>> passenger = passenger + 1
>>> passanger
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    passanger
NameError: name 'passanger' is not defined
>>> passenger
5
>>> 