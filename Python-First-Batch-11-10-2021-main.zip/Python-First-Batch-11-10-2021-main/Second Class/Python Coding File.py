Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  4 2021, 13:27:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 2+3
5
>>> 3-2
1
>>> 3*3
9
>>> 4/2
2.0
>>> 4%2
0
>>> 5%2
1
>>> 4//2
2
>>> 3==2
False
>>> 3<2
False
>>> 3>2
True
>>> 2==2
True
>>> 2!=2
False
>>> 3!=2
True
>>> a = 10
>>> a
10
>>> a = 20
>>> a
20
>>> a += 10
>>> a
30
>>> a = a + 10
>>> a
40
>>> b = 50
>>> b -= 25
>>> b
25
>>> b *= 2
>>> b
50
\
>>> b %= 2
>>> b
0
>>> 50/2
25.0
>>> 
>>> 


>>> 


>>> num1 = 20
>>> num3 = 30
>>> num1 > 10 and num3 > 20
True
>>> num1 = 5
>>> num1 > 10 and num3 > 20
False
>>> 0
0
>>> 3 and 0
0
>>> 3 and 3
3
>>> "vinay" and ""
''
>>> 