Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  4 2021, 13:27:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> sample_list = ["A", "B", "C", "D", "E"]
>>> 
>>> sample_list.append("F")
>>> 
>>> 
>>> sample_list.index("C")
2
>>> 
>>> sample_list.index("G")
Traceback (most recent call last):
  File "<pyshell#7>", line 1, in <module>
    sample_list.index("G")
ValueError: 'G' is not in list
>>> 
>>> 
>>> sample_list.insert(2,"I")
>>> 
>>> 
>>> sample_list
['A', 'B', 'I', 'C', 'D', 'E', 'F']
>>> 
>>> 
>>> sample_list.pop(2)
'I'
>>> 
>>> sample_list
['A', 'B', 'C', 'D', 'E', 'F']
>>> 
>>> 
>>> sample_list.append("C")
>>> 
>>> sample_list
['A', 'B', 'C', 'D', 'E', 'F', 'C']
>>> sample_list.remove("C")
>>> 
>>> sample_list
['A', 'B', 'D', 'E', 'F', 'C']
>>> 
>>> 
>>> sample_list.sort()
>>> 
>>> sample_list
['A', 'B', 'C', 'D', 'E', 'F']
>>> 
>>> 
>>> sample_list.reverse()
>>> 
>>> sample_list
['F', 'E', 'D', 'C', 'B', 'A']
>>> 
>>> 
>>> sample_list[::-1]
['A', 'B', 'C', 'D', 'E', 'F']
>>> 
>>> 