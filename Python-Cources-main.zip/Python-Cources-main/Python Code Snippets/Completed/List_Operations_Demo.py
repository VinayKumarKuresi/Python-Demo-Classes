Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  4 2021, 13:27:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> sample_list = []
>>> 
>>> sample_list
[]
>>> 
>>> student_name = ["Vinay", "Kumar", "Kuresi"]
>>> 
>>> student_name
['Vinay', 'Kumar', 'Kuresi']
>>> 
>>> 
>>> student_marks = ["Vinay", "50", "Kumar", "55", "Kuresi", "60"]
>>> 
>>> student_marks
['Vinay', '50', 'Kumar', '55', 'Kuresi', '60']
>>> 
>>> 
>>> sample_list = [None]*5
>>> sample_list
[None, None, None, None, None]
>>> 
>>> 
>>> sample_list[3] = "Vinay"
>>> 
>>> sample_list
[None, None, None, 'Vinay', None]
>>> 
>>> 
>>> len(sample_list)
5
>>> 
>>> 
>>> 