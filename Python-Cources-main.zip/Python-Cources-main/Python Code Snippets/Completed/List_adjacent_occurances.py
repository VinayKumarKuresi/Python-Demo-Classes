
'''
    List -> Operations, Iterations.

    problem :
        List :
            same number in adjacent positions
            display the count of such occurences

    [2, 2, 5, 100, -10, -10, 5, 0, 0] -> 3
    [10, 20, 30, 40, 30, 20] -> 0
    [1, 3, 3, 2, 7, 7, 7, 10] -> 3

'''

sample_list = [
                [2, 2, 5, 100, -10, -10, 5, 0, 0],
                [10, 20, 30, 40, 30, 20],
                [1, 3, 3, 2, 7, 7, 7, 10]
              ]
count = 0

for list in sample_list : 
    for index in range(len(list)-1):
        if list[index] == list[index+1]:
            count += 1
    print("Count of adjacent Occurences in ", list, " is : ",  count)
    count = 0