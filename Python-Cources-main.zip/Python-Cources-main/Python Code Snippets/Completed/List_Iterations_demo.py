
list_of_students = [1001, 1002, 1003]

'''
    Iterate the Loop : 
            1) range()
                - start postion index
                - end position index

                * end range value doesn't included.
                ** it will iterates till last before index value

            2) in Keyword
'''

# using range() function
'''
for index in range(0, len(list_of_students)):
    print(list_of_students[index])
'''

# using in keyword
'''
for id in list_of_students:
    print(id)
'''

# find out an element
# using if..in syntax

student_id = 1006

if student_id in list_of_students:
    print("Student Found")
else:
    print("Student Not Found")



