
# sample_list = [1,1,5,100,-20,-20,0,0,0]

# count = 0

# for i in range(len(sample_list)-1):
#     if sample_list[i] == sample_list[i+1]:
#         count += 1

# print("Total number of Occurances : ", count)


# same number in the adjacent positions
# Display the count of such adjacent positions

# [2,2,33,200,100,100,7,0,0] -> 3
# [10, 20, -30, 40, 15] -> 0
# [5, 4, 4, 5, -10, -10, 7] -> 2

sample_list = [2,2,33,200,100,100,7,0,0]

count = 0

for index in range(len(sample_list)-1):
    if sample_list[index] == sample_list[index+1]:
        count += 1

print("Count of adjancent Occurances : ", count)