
list_of_students = [1001, 1002, 1003]

'''
    Iterate the list:

            1) range()

                - start position
                - end position

                * end position value doesn't included.
                ** it will iterate till end before value
                i.e, len(list_of_students)-1 -> index value.

                    len(list_of_students) -> 3

                    range(0,3) -> 0, 1, 2

                    range(0, len(list_of_students)+1) -> 0, 1, 2, 3

            2) in Keyword

                - used to check if a value is present in a sequence(List, string etc).
                - used to iterate through a sequence in a for loop
'''

# using range() function

# for index in range(0, len(list_of_students)):
#     # id of students
#     print("Student ID : ",list_of_students[index])

# in Keyword

# for student_id in list_of_students:
#     # id of student
#     print("Student ID : ",student_id)


'''
    Check if a value present in a List:

            - if..in syntax
'''

student_id = 1607

if student_id in list_of_students:
    print("Student Found")
else:
    print("Student Not Found")