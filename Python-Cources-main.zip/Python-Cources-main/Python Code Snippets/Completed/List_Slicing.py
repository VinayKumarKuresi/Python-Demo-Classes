Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  4 2021, 13:27:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> student_ids = [1001, 1002, 1003, 1004, 1005]
>>> 
>>> student_ids
[1001, 1002, 1003, 1004, 1005]
>>> 
>>> 
>>> # 1001, 1003, 1003, 1004, 1005
>>> #   0     1     2     3     4
>>> #  -5    -4    -3    -2    -1
>>> 
>>> sub_list = student_ids[1:4]
>>> 
>>> sub_list
[1002, 1003, 1004]
>>> 
>>> 
>>> student_ids[-2]
1004
>>> 
>>> 
>>> student_ids[len(student_ids) - 1]
1005
>>> student_ids[len(student_ids) - 2]
1004
>>> 
>>> student_ids[-4:-1]
[1002, 1003, 1004]
>>> student_ids[1:4]
[1002, 1003, 1004]
>>> 