
# 2 x 3 matrix
A = [
    [1, 2, 3],
    [5, 6, 7]
]

# 3 x 2 matrix
B = [
    [1, 2],
    [3, 4],
    [5, 6]
]

# result is 2 x 2 matrix
result = [
    [0, 0],
    [0, 0]
]

# result = [[sum( a*b for a, b in zip(row, col)) for col in zip(*B)] for row in A]

# # Iterate through rows of A
# for row in range(len(A)):
#     # Iterate through col of B
#     for col in range(len(B[0])):
#         # Iterate through rows of B
#         for com in range(len(B)):
#             result[row][col] += A[row][com] * B[com][col]


# print(result)

# for row in result:
#     print(row)

import numpy as np
result = np.dot(A, B)

print(result)

# for row in result:
#     print(row)




