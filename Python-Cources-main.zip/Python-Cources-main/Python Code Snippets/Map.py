
# -----------------------------------------------------------

# def find_length(string):
#     return len(string)

# string_lengths = map(find_length, ["Vinay", "Kumar", "Kuresi"])

# print(string_lengths)
# print(list(string_lengths))

# string_lengths = list(map(lambda name : len(name), ["Vinay", "Kumar", "Kuresi"]))
# print(string_lengths)

# -----------------------------------------------------------

# string = "HAL"

# toggle = list(map(lambda letter : chr(ord(letter)+1), string))

# print(toggle)

# print("".join(map(lambda letter : chr(ord(letter)+1), string)))



def addition(num1, num2):
    return num1+num2

print(list(map(addition, [1,3,5], [2,4,6])))

