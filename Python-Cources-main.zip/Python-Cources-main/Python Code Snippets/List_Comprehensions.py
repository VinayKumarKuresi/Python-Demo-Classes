
# tuples, string, list


# [expression(element) for element in list]

# -----------------------------------------------------
'''
sample_numbers = [2, 4, 6, 8]

new_sample_numbers = []

for num in sample_numbers:
    new_sample_numbers.append(num*2)
print(new_sample_numbers)

new_sample_numbers = [ num*2  for num in sample_numbers]
print(new_sample_numbers)
'''
#--------------------------------------------------------
'''
each_letter = [letter for letter in "Vinay"]
each_letter = [letter.upper() for letter in "Vinay"]

print(each_letter)
'''
# -------------------------------------------------------
'''
airlines = ["IndiGo", "AirIndia", "SpiceJet", "Vistara", "TruJet"]
avaible_airlines = []

for airline in airlines:
    if airline != "AirIndia" and airline != "TruJet":
        avaible_airlines.append(airline)

print(avaible_airlines)

avaible_airlines = [ airline for airline in airlines if  airline != "AirIndia" if airline != "TruJet"]
print(avaible_airlines)
'''
# ------------------------------------------------------------

A = [[x *  100, x] [x % 2 != 0] for x in range(1, 10)]
print(A)

# ----------------------------------------------

even_numbers = []
odd_numbers = []

numbers = [ "Even" if num%2 == 0 else "Odd" for num in range(8)]
# print(numbers, even_numbers, odd_numbers)


# =--------------------------------------------

matrix = []
count = 1
# for row in range(3):
#     matrix.append([])
#     for col in range(4):
#         matrix[row].append(count)
#         count += 1
# # matrix[row].append(col+1)
# print(matrix)

# matrix = [list(map(lambda count: count+1, [ col for col in range(4)])) for row in range(3)]
# matrix = [[col for col in range(4)] for row in range(3)]
# print(matrix)

flatten_matrix = [val for row in matrix for val in row]

smaller_elements = [val for row in matrix for val in row if val < 5]

# ----------------------------------------------

transpose = []

matrix = [[1,2], [3,4], [5,6], [7,8]]

for col in range(len(matrix[0])):
    transpose_row = []

    for row in matrix:
        transpose_row.append(row[col])
    
    transpose.append(transpose_row)

# print(transpose)

original_matrix = []
original_matrix = [[row[col] for row in transpose] for col in range(len(transpose[0]))]

# print(original_matrix)

# ----------------------------------------------

'''
import time

# n = 10

n = 10000000

start = time.time()

sample_list = []
for num in range(n):
    num*10
    # sample_list.append(num*10)
# print(sample_list)

stop = time.time()

print("The time taken for For loop : ", stop-start)

start = time.time()

sample_list = [num*10 for num in range(n)]
# print(sample_list)

stop = time.time()

print("The time taken for List Comprehension : ", stop-start)

'''

# ----------------------------------------------



