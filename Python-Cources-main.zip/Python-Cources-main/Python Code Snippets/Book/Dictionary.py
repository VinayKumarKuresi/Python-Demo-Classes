
sample_dictionay = {}

sample_dictionay["one"] = "This is One"

sample_dictionay[2] = "This is Two"

print(sample_dictionay)

print(sample_dictionay["one"])

print(sample_dictionay[2])

tiny_dictionary = {"name" : "John", "code" : 6734, "dept" : "sales"}

