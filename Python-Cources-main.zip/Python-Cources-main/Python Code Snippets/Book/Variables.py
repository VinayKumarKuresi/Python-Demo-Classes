
a = b = c = 1

a, b, c = 1, 2, "John"

print(a, b, c)

var1 = 1
var2 = 2

print(var1, var2)

del var1

print(var1)

