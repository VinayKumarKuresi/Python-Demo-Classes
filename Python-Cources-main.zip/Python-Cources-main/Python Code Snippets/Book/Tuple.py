
sample_tuple = ("abcd", 786, 2.23, "John", 70.2, 123)

sample_tuple_2 =  ("Kumar", "Tutorials")

print(sample_tuple)

print(sample_tuple[0])

print(sample_tuple[2 : ])

print(sample_tuple[1:3])

print(sample_tuple * 2)

print(sample_tuple + sample_tuple_2)

