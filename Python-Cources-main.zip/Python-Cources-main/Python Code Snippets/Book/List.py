
sample_list = ["abcd", 786, 2.23, "John", 70.2, 123]

sample_list_2 = ["Kumar", "Tutorials"]

print(sample_list)
print(sample_list[0])

print(sample_list[1:3])

print(sample_list[2:])

print(sample_list_2 * 2)

print(sample_list + sample_list_2)





