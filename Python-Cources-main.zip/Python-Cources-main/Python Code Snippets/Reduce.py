
from functools import reduce

sample_list = [2, 4, 6, 8, 10]


sum = reduce((lambda x, y : x + y), sample_list)

print(sum)

def multiplication(num1, num2):
    print("Num_1 = ", num1, " Num_2 = ", num2)
    return num1 * num2

factorial  = reduce(multiplication, range(1, 6))
print("Factorial of 5 : ", factorial)

print(reduce(lambda x, y : x * y, range(1, 6)))


largest_number = reduce(lambda a, b : a if a > b else b, sample_list)

# print(sample_list)
