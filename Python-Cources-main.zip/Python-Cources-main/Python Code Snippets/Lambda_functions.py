
# anonymous functions
# 1) can take any number of Arguments
# 2) but can have only one expression.

# lambda arguments : expression

# -----------------------------------------------------------

x = lambda y: y*10
# print(lambda y: y*10)
# print(x(10))



def addition (a, b, c):
    return a + b + c

# print(addition(2, 4, 6))

add = lambda a, b, c : a + b + c
# print(add(2, 4, 6))

# (lambda a, b, c : print(a + b + c))(2, 4, 6)

# -----------------------------------------------------------

tables = [lambda x=y: x**2 for y in range(2, 11, 2)]
# print(list(tables))
# tables = [lambda x=y: print(x*10) for y in range(1, 11)]
# # print(tables)
# tables = []

# for i in range(1, 11):
#     tables.append(i*10)
    # print(tables.append(i*10))

# print(tables)

# for table in tables:
#     print(table())

# for table in tables:
#     table()
    # print(table())

# squares = list(map(lambda num : num**2, [num for num in range(2, 11, 2)]))
# print(squares)

squares = list(map(lambda num : num**2, range(2, 11, 2)))
# print(squares)

# squares = lambda n :( num**2 for num in range(n))
# print(squares(6))

squares = lambda :( num**2 for num in range(2, 11, 2))
# print(squares())
# print(list(squares()))

# for square in squares():
#     print(square)

squares = map(lambda num : [num * 2 , num] [num%2 != 0], range(1, 12))
# print(list(squares))

# -----------------------------------------------------------

# even_numbers = []

value = lambda a: a > 10 and a< 20
# print(value(6))

# value = lambda a : [a ** 2, a] [a % 2 == 0]
# print(value(6))

check_number = lambda a : "Even Number" if a%2 == 0 else "Odd Number"
# print(check_number(7))

# -----------------------------------------------------------

greatest_number = lambda a, b, c : a if( a >= b and a >= c) else ( b if b >= a  and b >= c else c)
# print(greatest_number(3, 5, 6))

# -----------------------------------------------------------

sample_list = [
                [3, 2, 5],
                [13, 23, 19],
                [23, 34, 2]
              ]

sortedList = lambda list : (sorted(num) for num in list)

second_largest = lambda list , func : [row[len(row) - 2] for row in func(list)]

res = second_largest(sample_list, sortedList)

print(res)

# -----------------------------------------------------------

