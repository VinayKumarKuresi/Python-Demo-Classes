
# -----------------------------------------------------------

sample_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

def create_even_list(list1):
    list2 = [num for num in list1 if num%2 == 0]
    return list2

print(create_even_list(sample_list))

def check_even(num):
    if num%2 == 0:
        return num

even_list = list(filter(check_even, sample_list))

# even_list = list(filter(lambda num : num%2 == 0 , sample_list))

print(even_list)

# -----------------------------------------------------------

