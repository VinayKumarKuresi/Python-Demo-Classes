
num=10
count=0

while(count <= num):
    if(count%2 == 0):
        pass
    else:
        print(count)
    count+=1 
