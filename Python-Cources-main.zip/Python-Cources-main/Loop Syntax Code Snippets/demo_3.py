
start = 1
end = 10
step = 1

for passenger_count in range(start, end, step):
    print("Immigration check is done for passenger : ", passenger_count)


names = ["Vinay", "Kumar", "Hari"]

for name in names:
    print(name, " is present in the Class")


num=int(input("Enter a number : "))
total=0
while(num>0):
    sum = num%10
    total = total + sum
    num = num//10

print("The total sum of digits is:",total)

