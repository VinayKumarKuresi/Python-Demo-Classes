
print("Class Details : ")

for name in "Kumar", "Praveen", "Rahul", "Hari", "Vinay", "Raju":

    if name == "Kumar" or name == "Praveen" or name == "Raju":
        print(name, " is the student of the class")
        continue

    if name == "Vinay":
        print(name, " is the Principal of the class")
        break

    if name == "Rahul" or name == "Hari":
        print(name, " is the teacher of the class")

    print("Next Name : ")
