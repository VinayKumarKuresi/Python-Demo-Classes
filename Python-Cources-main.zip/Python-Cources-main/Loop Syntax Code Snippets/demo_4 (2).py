
# nested loop

'''

    Outer Loop -> parent Loop
        Inside Loop -> Child Loop

'''

'''

    prime number : has only two factors -> 1 and itself
    composite number : has more than two factors

'''

'''

    1) For
        For
    
    2) For
        while

    3) While
        while

'''

from math import sqrt

num1 = int(input("Enter the First Number : "))
num2 = int(input("Enter the Second Number : "))

# to check whether the prime is encountered or not
flag = 1
# to check how many iterations the inner loop has done
count = 0

if num1 == 1 :
    print("Starting number should be greater than 1")
else:
    while(num1 < num2):

        divisor = 2
        while(divisor <= num1/divisor):
            count += 1
            if not(num1%divisor):
                break
            divisor = divisor+1


        # 
        
        if(divisor > num1/divisor):
            print(num1, " prime number")

        num1 += 1

print("Count : ", count)

'''

if num1 == 1 :
    print("Starting number should be greater than 1")
else:
    for number in range(num1, num2):
        flag = 1
        # last_number = number
        # last_number = int(number/2) + 1
        last_number = int(sqrt(number))

        divisor = 2
        while(divisor <= last_number):
            count += 1

            if(number%divisor == 0):
                flag = 0
                break

            divisor += 1

        if(flag == 1):
            print(number, " is prime")

        # if(flag == 1):
        #     print(number, " is prime")
        # for divisor in range(2, last_number):
        #     count += 1

        #     if(number%divisor == 0):
        #         flag = 0
        #         break

       

print("Count : ", count)

'''

