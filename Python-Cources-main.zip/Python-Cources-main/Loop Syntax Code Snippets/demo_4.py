
from math import sqrt

num1 = int(input("Enter the First Number : "))
num2 = int(input("Enter the Second Number : "))
flag = 1
count = 0

# for number in range(num1, num2):
#     flag = 1
    # last_number = number
    # last_number = int(number/2) + 1
    # last_number = int(sqrt(number)) + 1
    # for divisor in range(2, last_number):
    #     count += 1

    #     if(number%divisor) == 0:
    #         flag = 0
    #         break

number = 2
while (number < 100) :

    divisor = 2
    while(divisor <= (number/divisor)):
        count += 1
        if not(number%divisor): break
        divisor = divisor + 1
      
    if (divisor > number/divisor) : 
        print(number, " is prime")

    number += 1

    # if (flag == 1):
    #     print(number, " is prime")

print("Count : ", count)