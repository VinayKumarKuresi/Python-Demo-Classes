
counter = 5
while (counter >= 5):
    print(counter)
    counter = counter + 1


limit = int(input("Enter the Number : "))

for counter in range(5, limit, -1):
    print(counter)


