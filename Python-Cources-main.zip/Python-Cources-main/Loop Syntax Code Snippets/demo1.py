print("Flights has landed")
print("Proceed for imigration check")
# passenger_count = 1
# print("Immigration check is done for passanger : ", passenger_count)
# passenger_count += 1
# print("Immigration check is done for passanger : ", passenger_count)
# passenger_count += 1
# print("Immigration check is done for passanger : ", passenger_count)
# passenger_count += 1
# print("Immigration check is done for passanger : ", passenger_count)
# passenger_count += 1
# print("Immigration check is done for passanger : ", passenger_count)

# for passenger_count in 1,2,3,4,5,6,7 .. 100 :
#     print("Immigration check is done for passanger : ", passenger_count)

start = 1
end = 10
step = 3

for passenger_count in range(start, end , step):
    print("Immigration check is done for passanger : ", passenger_count)



