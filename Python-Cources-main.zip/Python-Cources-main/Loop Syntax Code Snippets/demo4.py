
from math import sqrt

num1 = int(input("Enter the First Number : "))
num2 = int(input("Enter the Second Number : "))

count = 0
flag = 0
for number in range(num1, num2):
    # last_number = int(sqrt(number))
    last_number=number
    flag = 1
    for divisor in range(2, last_number+1):
        count += 1
        print(number%divisor)
        if(number%divisor == 0):
            flag = 0
            break
    if(flag==1):
        print(number, last_number, "is prime")

print("Count : ", count)

# i = 2
# count = 0
# while(i < 100):
#    j = 2
#    while(j <= (i/j)):
#       count += 1
#       if not(i%j): break
#       j = j + 1
#    if (j > i/j) : print(i, " is prime")
#    i = i + 1

# print("Count : ", count)
