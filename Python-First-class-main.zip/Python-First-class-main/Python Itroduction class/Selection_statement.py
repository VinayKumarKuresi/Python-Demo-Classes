
runway = "Not Free"
fuel = "low"

if runway == "free":
	print("Flight can land")
elif fuel == "low":
    print("Emegency landing")
else:
    print("You need to circle in air")


