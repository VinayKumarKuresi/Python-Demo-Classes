Python 3.7.8 (tags/v3.7.8:4b47a5b6ba, Jun 28 2020, 08:53:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> initial_planes = 100
>>> take_off_planes  = 40
>>> landed_flights = 60
>>> 
>>> current_number_of_flights = initial_planes - take_off_planes + landed_flights
>>> 
>>> current_number_of_flights
120
>>> runway = "free"
>>> if runway == "free":
	print("Flight can land")
else:
	print("You need to circle in air")

	
Flight can land
>>> runway = "Not free"
>>> 
>>> if runway == "free":
	print("Flight can land")
else:
	print("You need to circle in air")

	
You need to circle in air
>>> 