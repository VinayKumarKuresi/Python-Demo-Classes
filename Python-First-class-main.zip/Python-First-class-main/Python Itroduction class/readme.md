First Class(Pseudo code) : 
  
    1) What is python
    2) What is program
    3) Flight Example
    4) Problem Solving(Algorithm)
    5) Representation of Algorithm :
          a) Pseudo-code
          b) Flow-chart
    6) Variables.
    7) Operators :
          a) Arithematic Operator
          b) Relational Operator
          c) Logical Operator
          
    8) Flow of Control
          a) Selection Control
          b) Repetitive Control
          
       
       
          
          
